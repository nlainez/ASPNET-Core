using System;

public class FirstApp{
    
    public static void Main(string[]args){
        
        Console.WriteLine("Our First App via DNX Command Line!!!");
    }
   
    
}
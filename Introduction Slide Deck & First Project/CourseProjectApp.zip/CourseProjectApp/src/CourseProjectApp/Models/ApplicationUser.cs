﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;

namespace CourseProjectApp.Models
{
    public class ApplicationUser:IdentityUser
    {

    }
}